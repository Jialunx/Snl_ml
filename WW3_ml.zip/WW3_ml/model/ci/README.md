# Continuous Integration
WW3 uses Github Actions for continuous integration.

This directory contains a Spack environment file to build library dependencies such as NetCDF, ESMF, ParMETIS, SCOTCH and g2.

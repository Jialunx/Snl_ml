# Tools Directory Readme 

The tools directory contains: 

* bash/ - a folder with scripts that convert inp to nml input files 
* ftn2src.sh - a script that converts ftn/ folder with switch preprocesssing to src/ folder with CPP if defs
* switch2cpp.awk - the script for converting ftn -> CPP 

# To convert ftn to src 

From the model/tools directory run the following script: 
sh ftn2src.sh

Your ftn directory should now be converted to a src directory.


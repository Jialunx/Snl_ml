### Contributing to WW3

All contributions to this project will be released under the [GNU Lesser General Public License 3.0](https://www.gnu.org/licenses/lgpl-3.0.en.html) (LGPL). Some files in this project have their own license embedded in them, in these cases the terms of the more restrictive license will hold. By submitting a pull request, you are agreeing to comply with the application of this license, and represent and warrant that you are legally entitled to provide these contributions and to agree to the application of this license. 

© 2009 National Weather Service National Oceanic and Atmospheric Administration.
All rights reserved. WAVEWATCH III® is a trademark of the National Weather Service. No unauthorized use without permission.
